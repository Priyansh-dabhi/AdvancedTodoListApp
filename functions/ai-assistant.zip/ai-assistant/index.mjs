// functions/ai-assistant/index.mjs
import { GoogleGenAI } from "@google/genai";

function readPayload() {
  try {
    return JSON.parse(process.env.APPWRITE_FUNCTION_EVENT_DATA || "{}");
  } catch {
    return {};
  }
}

(async () => {
  try {
    const payload = readPayload();
    const userText = payload.prompt || payload.task || "Hello from AI function";

    // Init Gemini client using API key from Appwrite env
    const client = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    // Call the model
    const response = await client.models.generateContent({
      model: "gemini-2.5-flash", // choose your available model
      contents: userText
    });

    let text = response.text || response.response?.text || JSON.stringify(response);

    // Try parse JSON if model returns structured output
    try {
      const parsed = JSON.parse(text);
      console.log(JSON.stringify(parsed)); // Appwrite captures this as responseBody
    } catch {
      console.log(JSON.stringify({ reply: text }));
    }

    process.exit(0);
  } catch (e) {
    console.error(e);
    console.log(JSON.stringify({ error: e.message || String(e) }));
    process.exit(1);
  }
})();
